(() => {
  'use strict';

  const state = {
    data: null,
    terms: [],
    categories: [],
    activeCategories: new Set(),
    query: '',
    displayCount: 50,
    votedIds: new Set(),
  };

  const PAGE_SIZE = 50;

  const el = {
    searchInput: document.getElementById('search-input'),
    clearBtn: document.getElementById('clear-search'),
    suggestions: document.getElementById('suggestions'),
    categoryList: document.getElementById('category-list'),
    selectAll: document.getElementById('select-all'),
    selectNone: document.getElementById('select-none'),
    resultsCount: document.getElementById('results-count'),
    resultsBody: document.getElementById('results-body'),
    emptyState: document.getElementById('empty-state'),
    loadMore: document.getElementById('load-more'),
    statTerms: document.getElementById('stat-terms'),
    statFields: document.getElementById('stat-fields'),
    statShown: document.getElementById('stat-shown'),
    heroCount: document.getElementById('hero-count'),
    heroCatCount: document.getElementById('hero-cat-count'),
    fieldSelect: document.getElementById('field-select'),
    contributeForm: document.getElementById('contribute-form'),
    contributeMsg: document.getElementById('contribute-msg'),
    submitBtn: document.getElementById('submit-btn'),
    toast: document.getElementById('toast'),
    tableShell: document.querySelector('.table-shell'),
    year: document.getElementById('year'),
    themeToggle: document.getElementById('theme-toggle'),
    themeColorMeta: document.getElementById('theme-color-meta'),
  };

  el.year.textContent = new Date().getFullYear();

  // ---------- theme (light/dark) ----------
  // The <head> inline script already set data-theme from the OS preference
  // before first paint. This just wires the manual toggle for the rest of
  // the session — no localStorage/cookies, so it resets to the OS
  // preference on next visit rather than persisting a choice.
  const THEME_COLORS = { light: '#f7f1e3', dark: '#121110' };
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    if (el.themeColorMeta) el.themeColorMeta.setAttribute('content', THEME_COLORS[theme]);
    if (el.themeToggle) {
      el.themeToggle.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
    }
  }
  if (el.themeToggle) {
    applyTheme(document.documentElement.getAttribute('data-theme') || 'light');
    el.themeToggle.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
      applyTheme(current === 'dark' ? 'light' : 'dark');
    });
  }

  // ---------- utilities ----------
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function highlight(text, query) {
    if (!query || !text) return escapeHtml(text || '');
    const escaped = escapeHtml(text);
    const q = escapeHtml(query).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return escaped.replace(new RegExp('(' + q + ')', 'ig'), '<mark>$1</mark>');
  }

  function showToast(msg, ms = 2600) {
    el.toast.textContent = msg;
    el.toast.classList.add('show');
    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => el.toast.classList.remove('show'), ms);
  }

  function debounce(fn, wait) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), wait); };
  }

  // ---------- data load ----------
  fetch('content.json')
    .then((r) => {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    })
    .then((data) => {
      state.data = data;
      state.terms = data.terms;
      state.categories = data.categories.slice().sort((a, b) => a.label.localeCompare(b.label));
      state.activeCategories = new Set(state.categories.map((c) => c.id));

      el.statTerms.textContent = data.meta.totalTerms.toLocaleString();
      el.statFields.textContent = data.meta.totalCategories;
      el.heroCount.textContent = data.meta.totalTerms.toLocaleString() + ' technical terms';
      el.heroCatCount.textContent = data.meta.totalCategories + ' fields';

      renderCategoryChips();
      populateFieldSelect();
      render();
    })
    .catch((err) => {
      el.resultsCount.textContent = 'Could not load the glossary data.';
      el.emptyState.hidden = false;
      el.emptyState.textContent = 'content.json failed to load (' + err.message + '). If you\u2019re previewing this outside of a real web server, serve the folder locally or deploy it to Netlify — a relative fetch() for content.json needs to run over http(s), not from a bare file preview.';
    });

  // ---------- category chips ----------
  function renderCategoryChips() {
    el.categoryList.innerHTML = state.categories.map((c) => `
      <div class="cat-chip">
        <input type="checkbox" id="cat-${c.id}" value="${c.id}" checked>
        <label for="cat-${c.id}">
          <span class="tick"></span>${escapeHtml(c.label)}
          <span class="count">${c.count}</span>
        </label>
      </div>
    `).join('');

    el.categoryList.addEventListener('change', (e) => {
      if (e.target.matches('input[type="checkbox"]')) {
        const id = e.target.value;
        if (e.target.checked) state.activeCategories.add(id);
        else state.activeCategories.delete(id);
        state.displayCount = PAGE_SIZE;
        render();
      }
    });
  }

  el.selectAll.addEventListener('click', () => {
    state.activeCategories = new Set(state.categories.map((c) => c.id));
    el.categoryList.querySelectorAll('input[type="checkbox"]').forEach((cb) => (cb.checked = true));
    state.displayCount = PAGE_SIZE;
    render();
  });

  el.selectNone.addEventListener('click', () => {
    state.activeCategories.clear();
    el.categoryList.querySelectorAll('input[type="checkbox"]').forEach((cb) => (cb.checked = false));
    state.displayCount = PAGE_SIZE;
    render();
  });

  function populateFieldSelect() {
    const opts = state.categories.map((c) => `<option value="${escapeHtml(c.label)}">${escapeHtml(c.label)}</option>`).join('');
    el.fieldSelect.insertAdjacentHTML('beforeend', opts);
  }

  // ---------- search ----------
  function scoreMatch(term, q) {
    const t = term.term.toLowerCase();
    if (t === q) return 100;
    if (t.startsWith(q)) return 80;
    if (t.includes(q)) return 60;
    const hay = (term.definition + ' ' + term.hint + ' ' + term.subfield).toLowerCase();
    if (hay.includes(q)) return 20;
    return 0;
  }

  function computeResults() {
    const q = state.query.trim().toLowerCase();
    let results = state.terms.filter((t) => state.activeCategories.has(t.category));
    if (q) {
      results = results
        .map((t) => ({ t, s: scoreMatch(t, q) }))
        .filter((x) => x.s > 0)
        .sort((a, b) => b.s - a.s)
        .map((x) => x.t);
    }
    return results;
  }

  function categoryLabel(id) {
    const c = state.categories.find((c) => c.id === id);
    return c ? c.label : id;
  }

  function render() {
    const results = computeResults();
    el.statShown.textContent = results.length.toLocaleString();

    if (results.length === 0) {
      el.resultsBody.innerHTML = '';
      el.emptyState.hidden = false;
      el.emptyState.textContent = 'No matches for that search. Try a different term, or widen your field selection above.';
      el.resultsCount.textContent = '0 matches';
      el.loadMore.hidden = true;
      return;
    }
    el.emptyState.hidden = true;

    const shown = Math.min(state.displayCount, results.length);
    el.resultsCount.textContent = `Showing ${shown.toLocaleString()} of ${results.length.toLocaleString()} matching terms`;

    const q = state.query.trim();
    const rows = results.slice(0, shown).map((t) => {
      const hasHint = !!t.hint && t.hint !== t.definition;
      const deTag = t.de ? `<span class="def-de">DE: ${highlight(t.de, q)}</span>` : '';
      const subfield = (t.subfield && t.subfield !== categoryLabel(t.category)) ? `<span class="subfield">${escapeHtml(t.subfield)}</span>` : '';
      const voted = state.votedIds.has(t.id);
      return `
        <tr>
          <td class="term-cell" data-label="Term">${highlight(t.term || '—', q)}</td>
          <td class="def-cell" data-label="Meaning">
            <div class="def-main">${highlight(t.definition || (hasHint ? '' : '—'), q)}</div>
            ${hasHint ? `<div class="def-hint">${highlight(t.hint, q)}</div>` : ''}
            ${deTag}
          </td>
          <td class="field-cell" data-label="Field">
            <span class="field-tag">${escapeHtml(categoryLabel(t.category))}</span>
            ${subfield}
          </td>
          <td data-label="Feedback">
            ${voted
              ? `<span class="stamp-thanks">Thanks for the feedback</span>`
              : `<div class="stamp-row" data-id="${t.id}" data-term="${escapeHtml(t.term)}" data-cat="${escapeHtml(categoryLabel(t.category))}">
                  <button type="button" class="stamp-btn" data-r="match" title="This definition is correct">✓ Match</button>
                  <button type="button" class="stamp-btn" data-r="miss" title="This definition is wrong">✕ Miss</button>
                  <button type="button" class="stamp-btn" data-r="unclear" title="Not sure / unclear">? Unclear</button>
                </div>`
            }
          </td>
        </tr>`;
    }).join('');

    el.resultsBody.innerHTML = rows;
    el.loadMore.hidden = shown >= results.length;
  }

  el.loadMore.addEventListener('click', () => {
    state.displayCount += PAGE_SIZE;
    render();
  });

  const onSearchInput = debounce(() => {
    state.query = el.searchInput.value;
    state.displayCount = PAGE_SIZE;
    el.clearBtn.classList.toggle('visible', !!state.query);
    renderSuggestions();
    render();
  }, 140);

  el.searchInput.addEventListener('input', onSearchInput);
  el.searchInput.addEventListener('focus', renderSuggestions);
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-wrap')) el.suggestions.hidden = true;
  });

  el.clearBtn.addEventListener('click', () => {
    el.searchInput.value = '';
    state.query = '';
    state.displayCount = PAGE_SIZE;
    el.clearBtn.classList.remove('visible');
    el.suggestions.hidden = true;
    render();
    el.searchInput.focus();
  });

  function renderSuggestions() {
    const q = el.searchInput.value.trim().toLowerCase();
    if (!q || !state.terms.length) { el.suggestions.hidden = true; return; }
    const matches = state.terms
      .filter((t) => t.term && t.term.toLowerCase().includes(q))
      .sort((a, b) => {
        const at = a.term.toLowerCase(), bt = b.term.toLowerCase();
        const as = at === q ? 0 : at.startsWith(q) ? 1 : 2;
        const bs = bt === q ? 0 : bt.startsWith(q) ? 1 : 2;
        return as - bs || at.length - bt.length;
      })
      .slice(0, 6);

    if (!matches.length) { el.suggestions.hidden = true; return; }

    el.suggestions.innerHTML = matches.map((t) => `
      <li><button type="button" data-term="${escapeHtml(t.term)}">
        <span class="s-term">${highlight(t.term, q)}</span>
        <span class="s-def">${escapeHtml(t.definition || t.hint || '')}</span>
      </button></li>
    `).join('');
    el.suggestions.hidden = false;
  }

  el.suggestions.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-term]');
    if (!btn) return;
    el.searchInput.value = btn.dataset.term;
    state.query = btn.dataset.term;
    state.displayCount = PAGE_SIZE;
    el.clearBtn.classList.add('visible');
    el.suggestions.hidden = true;
    render();
    document.querySelector('.results').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  // ---------- per-row feedback (Netlify Forms, AJAX) ----------
  el.resultsBody.addEventListener('click', (e) => {
    const btn = e.target.closest('.stamp-btn');
    if (!btn) return;
    const row = btn.closest('.stamp-row');
    const { id, term, cat } = row.dataset;
    const rating = btn.dataset.r;

    row.querySelectorAll('.stamp-btn').forEach((b) => (b.disabled = true));
    btn.classList.add('active');

    const body = new URLSearchParams({
      'form-name': 'acronym-feedback',
      term: term,
      category: cat,
      rating: rating,
    }).toString();

    fetch('/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
    })
      .then(() => {
        state.votedIds.add(id);
        row.innerHTML = '<span class="stamp-thanks">Thanks for the feedback</span>';
      })
      .catch(() => {
        row.querySelectorAll('.stamp-btn').forEach((b) => (b.disabled = false));
        btn.classList.remove('active');
        showToast('Could not send feedback — check your connection and try again.');
      });
  });

  // ---------- contribute form (Netlify Forms, AJAX with file upload) ----------
  el.contributeForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const form = el.contributeForm;
    const fileInput = form.querySelector('input[name="attachment"]');
    if (fileInput.files[0] && fileInput.files[0].size > 8 * 1024 * 1024) {
      el.contributeMsg.textContent = 'That file is over the 8 MB limit. Please attach a smaller file, or leave it out and mention it in the notes.';
      el.contributeMsg.className = 'form-msg err';
      return;
    }

    el.submitBtn.disabled = true;
    el.contributeMsg.textContent = 'Sending…';
    el.contributeMsg.className = 'form-msg';

    const formData = new FormData(form);

    fetch('/', { method: 'POST', body: formData })
      .then((r) => {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        form.reset();
        el.contributeMsg.textContent = 'Thanks — your submission is queued for editorial review.';
        el.contributeMsg.className = 'form-msg ok';
      })
      .catch(() => {
        el.contributeMsg.textContent = 'Something went wrong sending this. Please try again in a moment.';
        el.contributeMsg.className = 'form-msg err';
      })
      .finally(() => {
        el.submitBtn.disabled = false;
      });
  });

  // ---------- copy protection on the results table ----------
  ['copy', 'cut', 'contextmenu'].forEach((evt) => {
    el.tableShell.addEventListener(evt, (e) => {
      e.preventDefault();
      showToast('Copying is disabled for this table. Reach out via the contribute form for data access.');
    });
  });
  el.tableShell.addEventListener('keydown', (e) => {
    const k = e.key.toLowerCase();
    if ((e.ctrlKey || e.metaKey) && (k === 'c' || k === 'a' || k === 'x')) {
      e.preventDefault();
    }
  });
})();
