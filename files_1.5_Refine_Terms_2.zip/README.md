# Accronyms — DigitForge Field Glossary (v1.3)

A single searchable index of **5,791 technical acronyms** across **28 fields** — aerospace, SAP, lean manufacturing, renewable energy, CAD, IT, robotics, production engineering, manufacturing processes, and a couple of off-duty categories (gaming) — built from `Aboud_V1_4_Updated.xlsx`, `Robotics_Abb.xlsx`, `Dictionary_Production_Engineering.xlsx`, and `Verfahrenstechnik.xlsx`.

Live target: `accronyms.digitforge.io`

**Version history:**
- **v1.2** — 5,006 terms / 26 categories (`Aboud_V1_4_Updated.xlsx` + `Robotics_Abb.xlsx`)
- **v1.3** — 5,791 terms / 28 categories, adds `Production Engineering` (+600) and `Fertigungsverfahren` (+185)
- **v1.3 UI patch** (a.k.a. **v1.5** — "Refine Terms") — no data change. Fixes a sticky-header overlap bug in the results table, and adds a light/dark mode toggle grounded in `digitforge.io`'s actual palette (see *Theme system* below).
- **v1.6** — no data change. `Verfahrenstechnik.xlsx` and `Dictionary_Production_Engineering.xlsx` were re-uploaded and checked against what's already in `content.json`: identical row counts (600 / 185) and identical content, term-for-term. They were already merged in as of v1.3 and carried through v1.5 unchanged — nothing new to add. Re-verified and re-packaged as v1.6 rather than silently re-running a merge that would have produced the same result.

---

## What this is

Junior engineers and students walking into a new project meet a wall of shorthand — `MRP`, `FAL`, `VSM`, `WBS` — before anyone explains it. This tool is one search box in front of that wall: type a term, get a definition, filter by field, and — if the answer's wrong or missing — flag it or send a correction.

## Files in this deliverable

| File | Purpose |
|---|---|
| `index.html` | Markup + all styling (embedded `<style>`) |
| `app.js` | Search, filtering, pagination, feedback stamps, contribute form, copy protection |
| `content.json` | The glossary itself — 5,791 terms, parsed from four source workbooks |
| `README.md` | This file |
| `netlify.toml` | Optional — publish config + light security/caching headers |

All four core files match the deliverable format from your other DigitForge builds (index.html / app.js / content.json / README).

## Features (mapped to the spec in `Syntax_Accronyms.xlsx`)

- **Search bar with suggestions** — live, debounced search across term, definition, hint, and sub-field text. A dropdown suggests the top 6 matching terms as you type (client-side fuzzy matching — see *Honest limitations* below on the "AI suggesting" line in the spec).
- **Field filtering ("Anhacken")** — checkbox chips for all 25 categories, with **All** / **None** shortcuts, matching the "tick to choose the desired sheet" requirement.
- **Table display** — results render as a table (not cards), per the spec's explicit "Display the desired Table" wording, styled as a shop-floor routing tag / traveler card (perforated left edge, monospace stamped acronym) rather than a generic grid.
- **Feedback per result** — three stamp buttons (`✓ Match` / `✕ Miss` / `? Unclear`) on every row, matching the "Yes / No / Not Precise" requirement. Each vote posts to a Netlify Form (`acronym-feedback`) so you can review it in your Netlify dashboard.
- **Contribute form** — name, acronym, suggested definition, field, notes, and a single file attachment (`.docx / .pdf / .xlsx / .zip / .rar`), submitted via Netlify Forms (`contribute`). Nothing is auto-published — every submission sits in Netlify's Forms inbox for you (the editor) to review.
- **Copy protection** — the results table has `user-select: none`, and copy / cut / right-click / Ctrl+C / Ctrl+A are intercepted inside the table with a toast explaining why. This is a **soft UI deterrent**, not a security boundary — anyone using view-source or dev tools can still read the data. Said plainly in case it matters for how you describe the feature.
- **GitHub link** — footer and header both link to `github.com/AM101-svg/Accronyms`.
- **"All rights reserved to digitforge.io"** — footer copyright line, as specified.

## Data: how 5,791 terms were derived

`Aboud_V1_4_Updated.xlsx` has 28 sheets. Three are excluded from the glossary because they aren't term lists: `Tabelle2` (empty), `Plan_SDC` (a training-session planner), and `Kick-Off` (your own progress dashboard). The remaining 25 sheets were parsed with a header-aware script (`extract.py` — not shipped, since it's a one-time build tool, but ask if you want it) that:

- Matches columns by header text rather than position, so it copes with each sheet's slightly different labels (`Acronym` vs `Acronym `, `Definition` vs `Defenition`, `Filter: Field` vs `Field` vs `Filter`).
- Coalesces the one sheet with a genuinely misaligned column (`PM`, where "Definition" text lands in column B on some rows and column C on others) into a single definition field.
- Keeps the `DE` (German) column from the `Aerospace` sheet as a separate tag — currently populated on 9 entries, so treat it as a slot ready for future contributions rather than a fully-populated column.
- Drops rows that are entirely blank (some sheets had trailing rows where only the category column was filled down by accident — about 160 rows across the file).
- Keeps rows with a blank acronym but real text in the definition/hint (e.g. sub-bullets like the `5M Constraints` note in `SCM_MRP`) — they display with `—` in the Term column but stay fully searchable.

`Robotics_Abb.xlsx` was merged in as a 26th category the same way: single sheet, two columns (`Acronym / Word`, `Definition`), 1,000 terms, no blank rows, no duplicate terms — the cleanest source file in the set. It fills the `Robotics` slot your `Kick-Off` dashboard had already reserved but left empty.

**v1.3 adds two more categories:**

- **`Production Engineering`** (labeled `Production_Eng` in your request) — from `Dictionary_Production_Engineering.xlsx`, 600 bilingual terms (`Dictionary` sheet). Each entry's `term` keeps the source's combined "German – English" form (e.g. `Baugruppe – assembly (2)`) rather than splitting it, since the bilingual pairing is the point of this dictionary and splitting it would lose that. `definition` is the German explanation text as given (no separate English gloss exists in this source). The `Use Area (Thema)` column is preserved as `subfield`, e.g. `Grundlegende Begriffe der Produktion – Allgemeine Begriffe`.
- **`Fertigungsverfahren`** — from `Verfahrenstechnik.xlsx`, sheet `Glossar (200 Begriffe)`. The sheet name says 200 terms; the actual populated row count is **185** (confirmed against the sheet's own `Kategorie-Statistik` tab, which sums to 185 across its 7 categories) — flagging the discrepancy rather than quietly reporting 200. Worth a heads-up: this source glossary covers more ground than the name "Fertigungsverfahren" (manufacturing processes) narrowly implies — its own title is *"Glossar der Fertigungsverfahren & Verfahrenstechnik"* and its 7 sub-areas include forming, machining, joining, primary shaping, process engineering, surface/heat treatment, and quality management. Using it as a single category is fine at this size; if it grows, it may be worth splitting by `subfield` the way this glossary is a single sheet today. Since it has genuinely separate German and English text (`Bedeutung DE` / `Definition ENG`, both populated for every row), `definition` holds the English text and `de` holds the German — this is the same `de` field the `Aerospace` category already uses, so it renders with the existing "DE:" tag in the UI with no front-end changes needed.

Category counts as shipped:

| Field | Source sheet | Terms |
|---|---|---|
| ATA 100 (Aviation) | `ATA_100` | 95 |
| Aerospace | `Aerospace` | 257 |
| Aviation Wiki | `Aviation_Wiki` | 837 |
| Batteries | `Batteries` | 13 |
| Biomass | `Biomass` | 25 |
| CAD (CATIA / AutoCAD) | `CAD` | 364 |
| DOFUS (Game) | `DOFUS` | 56 |
| Email / PMTA (Mailing) | `MAILING pmta` | 323 |
| Engineering Drawing | `Eng_Drwaing` | 223 |
| Excel Shortcuts | `Excel_Shortcuts` | 118 |
| Fertigungsverfahren | `Verfahrenstechnik.xlsx` | 185 |
| Gaming (General) | `Gaming` | 37 |
| Grid & Energy Policy | `Grid` | 16 |
| Hydro & Geothermal | `Hydro & Geoth` | 46 |
| IT & Technology | `IT` | 204 |
| Industrial Engineering | `Industry` | 55 |
| Lean Management | `Lean` | 14 |
| Manufacturing | `Manufacturing` | 779 |
| Packaging | `Packaging` | 107 |
| Production Engineering | `Dictionary_Production_Engineering.xlsx` | 600 |
| Project Management | `PM` | 64 |
| RAID: Shadow Legends (Game) | `RAID` | 72 |
| Robotics | `Robotics Glossary` | 1,000 |
| Run Commands (CLI) | `Run_cmd` | 98 |
| SAP Modules | `SAP_M1+M2` | 49 |
| Solar / Photovoltaic | `PV` | 59 |
| Supply Chain & MRP | `SCM_MRP` | 76 |
| Wind Energy | `Wind` | 19 |
| **Total** | | **5,791** |

`content.json` schema, one entry:
```json
{
  "id": "aerospace-00142",
  "term": "PSP-Element",
  "definition": "Sometimes mentioned as WBS-element",
  "de": "",
  "hint": "MSN --> A320 - A321 Neo / MSV --> A350",
  "subfield": "Aerospace",
  "category": "aerospace"
}
```

## Theme system (light/dark) + the table header fix

**The bug:** the sticky table header was pinned with `position: sticky; top: 64px`, calculated against the page's own scroll and hardcoded to match the site header's height. That's fragile — any mismatch (font loading shifting row heights, browser zoom, etc.) let a sliver of the row above show through above the header, which is the overlap in your screenshot. Fixed properly: the results table now scrolls in its own pane (`.table-shell { max-height: 70vh; overflow-y: auto; }`) with its header sticky to *that* pane's top (`top: 0`), so it can't desync from the page layout. The perforated left-edge detail moved from a viewport-pinned overlay onto the table's own background, so it now scrolls with the rows instead of floating in place — that was a smaller latent bug the same investigation turned up.

**The palette:** I checked `digitforge.io` directly rather than guess — its declared theme color is a warm cream (`#f7f1e3`), not dark. So light is now the *true* default here too, built around that exact color, with the original dark-amber look kept as the alternate mode via the toggle in the header (moon/sun icon). On load, the page follows the OS-level light/dark preference (`prefers-color-scheme`); the toggle overrides that for the rest of the visit. There's intentionally no persistence (no `localStorage`/cookies) — the choice resets to the OS preference on the next visit rather than being remembered, which keeps this file simpler and avoids a storage dependency that isn't needed for the ask. Say if you'd rather it stuck.

All color values are CSS custom properties (`--bg`, `--surface`, `--text`, `--amber`, etc.) swapped via a `data-theme="light"|"dark"` attribute on `<html>` — every component references the variables rather than hardcoded colors, so both modes stay in sync automatically as the glossary evolves.

Two small matching touches pulled from the homepage's own style: the numbered section eyebrows (`01 Filter by field`, `02 · Glossary`, `03 Submit a correction…`) mirror `digitforge.io`'s own `01 Selected work` / `02 Toolkit` convention, and the hero headline now has the same italic-emphasis treatment the homepage uses on "*Engineer*".



This project is live via **Netlify Drop** (manual, not Git-connected — confirmed from the "Last deployed from Netlify Drop" label on the project overview). To push v1.3 live:

1. Open the project (`accronyms.digitforge.io`) in the Netlify dashboard.
2. In the left sidebar, select **Deploys**.
3. Drag the **entire updated folder** — all five files: `index.html`, `app.js`, `content.json`, `README.md`, `netlify.toml` — onto the drop zone there. Dropping only `content.json` would replace the whole published file set with just that one file and take the site down, since a manual deploy isn't incremental.
4. Netlify publishes straight to production; `accronyms.digitforge.io` picks it up immediately, no domain/DNS step needed since that's already configured.
5. Confirm per the checklist above.

`content.json` and `netlify.toml` here are unchanged from the v1.3 data update. `index.html` and `app.js` include the UI patch described above (table scroll/header fix, light/dark theme) — that's a deliberate front-end change for *this* update, unlike the v1.2 → v1.3 data-only upgrade.

## Deploying to accronyms.digitforge.io — step by step (first-time / fresh deploy)

**1. Deploy the site (creates a Netlify site with a random `*.netlify.app` URL first):**
- Fastest: drag the whole `accronyms` folder onto [app.netlify.com/drop](https://app.netlify.com/drop).
- Recommended going forward: push these files to `github.com/AM101-svg/Accronyms` (already referenced in the spec) and connect that repo in Netlify — *Add new site → Import an existing project*. You get automatic redeploys on every push instead of manual drag-and-drop, worth doing now that the glossary will keep growing toward the 5,000 / 10,000 / 15,000 / 20,000 milestones in your `Kick-Off` tracker.
- Either way, Netlify auto-detects the `contribute` and `acronym-feedback` forms because their markup is already present in the shipped HTML — no separate form setup step.

**2. Attach the subdomain:**
- In the new site's dashboard: **Domain management → Add a domain → Add a domain you already own**.
- Enter `accronyms.digitforge.io` and select **Verify**, then **Add domain**.
- Since `digitforge.io` is already on Netlify DNS from your other subdomains, Netlify recognizes the parent zone automatically and creates the `accronyms` DNS record for you — there's no separate external DNS step like there would be for a brand-new domain. If it instead offers a choice between Netlify DNS and an external provider, choose **Netlify DNS**, since that's where the rest of `digitforge.io` already lives.

**3. Wait for the certificate:**
Netlify auto-provisions a Let's Encrypt SSL certificate once the DNS record resolves. Since the parent zone is already on Netlify DNS this is usually minutes, not hours — the domain management page shows a pending/active status while it happens.

**4. Turn on form notifications** so contributions and feedback don't sit unseen: *Site configuration → Forms → Notifications → add email or Slack notification* for both `contribute` and `acronym-feedback`.

**5. Confirm:**
- Open `https://accronyms.digitforge.io` and check the stat strip reads **5,791 terms / 28 fields**.
- Filter to **Production Engineering** or **Fertigungsverfahren** only and search a term like `Baugruppe` or `Walzen` to confirm the new categories loaded.
- Submit a test entry through the contribute form and a test feedback stamp, then check Netlify's Forms tab picked both up.

## Local preview

```
cd accronyms
python3 -m http.server 8000
# open http://localhost:8000
```

Don't open `index.html` directly by double-clicking it — `fetch('content.json')` needs to run over `http(s)://`, and browsers block that from a bare `file://` path. Same reason a chat-embedded preview of this file may show a load error: use the local server command above, or just deploy it, to see it fully working.

## Honest limitations / things flagged rather than silently reinterpreted

- **"AI suggesting Acronyms" (spec, Condition 1):** implemented as a fast client-side fuzzy matcher, not a hosted AI model. A real AI-assisted version (e.g. a Netlify Function calling the Claude API to draft definitions for new contributions) is a clean next step, but needs a server-side API key, which a pure static site can't hold safely — noted as roadmap, not built silently as a fake "AI" label.
- **Drag-and-drop image → text conversion (spec, "Use" section, steps 1–3):** this text matches your Image2Text project's spec almost word for word and doesn't fit an acronym glossary — it reads like leftover boilerplate from that build's brief rather than a real requirement here. Not implemented; flag if I'm wrong and you did want an OCR feature bolted onto this tool.
- **ML / SQL / Power BI / Digital Twin (spec, "Methods"):** the actual pipeline is a one-time Python/openpyxl extraction into `content.json`. Wiring a live database + BI layer behind a static glossary site would be a different (larger) project — happy to scope it if the glossary is meant to become a live-editable system rather than a rebuild-on-update one.
- **Netlify Forms file uploads:** one file per field, 8 MB per request, 30-second upload timeout — Netlify's limits, not this app's. The form checks file size client-side before submitting so people get a clear message instead of a silent failure.
- **Copy protection is cosmetic**, as noted above — it stops casual copy-paste, not determined extraction.

## Roadmap / suggested next steps (KVP)

1. **Form notifications** (above) — otherwise contributions/feedback go unseen.
2. **Rebuild pipeline**: keep `extract.py` alongside the xlsx files in the repo, so updating the glossary is "edit the spreadsheet(s) → rerun the script → redeploy" instead of hand-editing JSON. It now needs to merge two source files (`Aboud_V1_4_Updated.xlsx` + `Robotics_Abb.xlsx`) instead of one — worth formalizing as a proper multi-file merge step rather than the one-off script used this time, especially if more standalone category files like `Robotics_Abb.xlsx` show up later.
3. The glossary now sits at 5,791 terms, comfortably past the 5,000-term goal in `Kick-Off`. `Aviation_Wiki` (837), `Manufacturing` (779), and the new `Production Engineering` (600) are your biggest single-category growth levers toward the 10,000-term goal; `Batteries` (13), `Wind` (19), and `Grid` (16) remain the sheets nearest their natural end.
4. **Analytics** (Netlify Analytics or a privacy-friendly option like Plausible) on search terms would show which fields get used most — useful signal for where to expand next.
5. If term count passes roughly 10,000–15,000, swap the linear in-browser search for a small pre-built search index (e.g. Fuse.js or a tiny inverted index) — not needed yet at 5,791.

---

© DigitForge. All rights reserved.
